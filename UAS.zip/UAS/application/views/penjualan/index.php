<php>
<!DOCTYPE html>
<html>
<body>

<h1>Pengalaman Kerja</h1>

<p>Saya pernah membuka usaha online di Tokopedia menjual baju-baju,sepatu dan fashion lainnya.<br>
Dalam bekerja melalui media sosial perlu extra kesabaran dalam menghadapi customer.<br>
Dimana ada customer yang tidak sabaran ada juga yang memiliki permintaan aneh-aneh.<br>
Terkadang juga terkendala dengan jaringan jika bertemu dengan customer yang selalu ingin di jawab dengan cepat.<br>
Selain berjualan online saya juga berjualan secara offline membuka warung kecil kecilan berjualan ciki dan lain sebagainya.<br> 
menghadapi anak anak kecil tidaklah mudah seperti membawa uang seribu ingin mendapat banyak jajanannya.<br> 
Itu harus menjelaskan lagi kepada mereka perlahan.
</body>
</html>
