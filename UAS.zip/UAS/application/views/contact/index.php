<?php
echo "<b>No HP     : 081220500345<br>";
echo "Email     : ryannathanael75@gmailcom<br>";
echo "Instagram : ryan__nathanael<br>";
echo "Twitter : ryan__nathanael";
?>