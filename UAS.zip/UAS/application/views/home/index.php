<?php
    echo "<p><center><H1>WELCOME TO MY PROFILE</H1></center></p>"
?>